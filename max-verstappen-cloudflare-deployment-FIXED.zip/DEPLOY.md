# 🚀 Cloudflare Pages Deployment

## Quick Deploy (Upload Method)

1. **Install dependencies**: `npm install`
2. **Build the project**: `npm run build`
3. **Upload to Cloudflare Pages**: Upload the entire project folder
4. **Build Settings**:
   - Build command: `npm run build`
   - Build output directory: `.next`
   - Node.js version: `18`

## Git Integration Method

1. **Push to GitHub**: Upload this folder to a GitHub repository
2. **Connect to Cloudflare Pages**: Link your GitHub repo
3. **Configure Build**:
   - Framework preset: `Next.js`
   - Build command: `npm run build`
   - Build output directory: `.next`

## Updating Data

After each race, edit the JSON files in `/data/` and redeploy:

```bash
# Update race result
node scripts/update-data.js --race="Race Name" --position=1 --points=25 --pole=true

# Commit and push (if using Git integration)
git add .
git commit -m "Update after [Race Name]"
git push
```

Your dashboard will be live on Cloudflare's global CDN! 🏁
